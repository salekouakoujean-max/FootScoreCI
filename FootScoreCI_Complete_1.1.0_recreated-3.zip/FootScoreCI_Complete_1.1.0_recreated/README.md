# FootScore CI 1.1.0 — projet source recréé

Application Android de scores de football avec interface WebView et serveur proxy.

## Important
- Ceci est le **projet source**, pas un APK/AAB signé.
- L'API football et sa clé restent côté serveur.
- Le serveur doit être déployé en HTTPS.
- Utiliser les annonces de test pendant le développement.
- Le compte AdMob et les étapes de paiement/vérification doivent être gérés avec un adulte responsable si nécessaire.

## Configuration
1. Dans `server/`, définir `FOOTBALL_API_KEY`.
2. Déployer le serveur en HTTPS.
3. Dans `android/app/build.gradle.kts`, remplacer `SERVER_BASE_URL` par l'URL publique du serveur.
4. Ouvrir `android/` dans Android Studio et synchroniser Gradle.
5. Tester l'application avant publication.

## AdMob
- App ID: `ca-app-pub-5439140185488234~9878055639`
- Release banner: `ca-app-pub-5439140185488234/1818285567`
- Debug banner: Google test ID `ca-app-pub-3940256099942544/9214589741`

## API proxy
Endpoints prévus : `/api/matches`, `/api/live-details`, `/api/standings`, `/api/health`.
